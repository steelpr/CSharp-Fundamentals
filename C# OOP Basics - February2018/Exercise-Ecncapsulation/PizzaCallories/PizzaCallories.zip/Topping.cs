﻿using System;
using System.Collections.Generic;
using System.Text;

public class Topping
{
    const double DEFAULT_MULTIPLIER = 2;

    Dictionary<string, double> topping = new Dictionary<string, double>
    {
        ["meat"] = 1.2,
        ["veggies"] = 0.8,
        ["cheese"] = 1.1,
        ["sauce"] = 0.9
    };

    private string name;
    private double weight;
  
    private double Multiplier => topping[Name];
    public double Calories => DEFAULT_MULTIPLIER * Weight * Multiplier;

    public Topping(string name, double weight)
    {
        Name = name;
        Weight = weight;
    }

    public string Name
    {
        get { return name; }
        set
        {
            Validator.ValidTopping(value, topping);
            name = value;
        }
    }

    public double Weight
    {
        get { return weight; }
        set
        {
            Validator.ValidToppingWeight(Name, value);
            weight = value;
        }
    }
}