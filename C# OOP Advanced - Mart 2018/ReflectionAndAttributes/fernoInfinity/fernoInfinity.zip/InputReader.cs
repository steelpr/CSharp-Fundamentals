﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfernoInfinity
{
    public class InputReader
    {
        internal string ReadLine() => Console.ReadLine();
    }
}
