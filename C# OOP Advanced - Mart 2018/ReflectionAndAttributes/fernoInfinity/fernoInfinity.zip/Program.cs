﻿using InfernoInfinity;
using System;

namespace fernoInfinity
{
    class Program
    {
        static void Main(string[] args)
        {
            new Engine().Run();
        }
    }
}
