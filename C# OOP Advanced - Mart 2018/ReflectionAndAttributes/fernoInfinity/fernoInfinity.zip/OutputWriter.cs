﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfernoInfinity
{
    public class OutputWriter
    {
        internal void WriteLine(string text) => Console.WriteLine(text);
    }
}
