﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights
{
    public interface ILightable
    {
        void ChangeLight(int count);

        void Add(string[] light);
    }
}
