﻿using System;
using System.Linq;
using System.Reflection;

namespace TrafficLights
{
    class Program
    {
        static void Main(string[] args)
        {
            Type type = Type.GetType("TrafficLights.TrafficLight");

            MethodInfo[] methodInfos = type.GetMethods(BindingFlags.Instance | BindingFlags.Public);

            string[] input = Console.ReadLine().Split();
            int count = int.Parse(Console.ReadLine());

            object createConst = Activator.CreateInstance(type);

            MethodInfo addMethod = methodInfos.First(m => m.Name == "Add");

            MethodInfo method = methodInfos.First(m => m.Name == "ChangeLight");

            addMethod.Invoke(createConst, new object[] { input });
            method.Invoke(createConst, new object[] { count });
        }
    }
}
