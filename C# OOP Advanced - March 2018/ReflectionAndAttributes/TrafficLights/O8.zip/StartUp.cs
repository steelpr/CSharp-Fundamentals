﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights
{
    public class StartUp
    {
        public static void Main()
        {
            new Engine().Run();
        }
    }
}
