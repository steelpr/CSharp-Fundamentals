﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights
{
    public enum LightColor
    {
        Red,
        Green,
        Yellow
    }
}
